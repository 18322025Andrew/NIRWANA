import React from 'react';
import { Route, Switch, BrowserRouter as Router } from 'react-router-dom';
import Login from './components/Login';
import DataInput from './components/DataInput';
import Measurement from './components/Measurement';
import SavedResults from './components/SavedResults';
import './App.css';
import './styles/styles.css'; // Import the styles

function App() {
  return (
    <Router>
      <Switch>
        <Route exact path="/" component={Login} />
        <Route path="/data-input" component={DataInput} />
        <Route path="/measurement" component={Measurement} />
        <Route path="/saved-results" component={SavedResults} />
      </Switch>
    </Router>
  );
}

export default App;
