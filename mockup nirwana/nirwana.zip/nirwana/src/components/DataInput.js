import React, { useState } from 'react';
import { Container, TextField, Button, Typography, Box } from '@mui/material';
import { useHistory } from 'react-router-dom';

const DataInput = () => {
  const [name, setName] = useState('');
  const [height, setHeight] = useState('');
  const [weight, setWeight] = useState('');
  const history = useHistory();

  const handleSubmit = () => {
    history.push({
      pathname: '/measurement',
      state: { name, height, weight }
    });
  };

  const handleSeePastResult = () => {
    history.push('/saved-results');
  };

  return (
    <Container maxWidth="xs" className="data-input-container">
      <Typography variant="h4" align="center">Data Input</Typography>
      <TextField 
        label="Name" 
        variant="outlined" 
        fullWidth 
        margin="normal" 
        value={name} 
        onChange={(e) => setName(e.target.value)} 
      />
      <TextField 
        label="Height (cm)" 
        variant="outlined" 
        fullWidth 
        margin="normal" 
        value={height} 
        onChange={(e) => setHeight(e.target.value)} 
      />
      <TextField 
        label="Weight (kg)" 
        variant="outlined" 
        fullWidth 
        margin="normal" 
        value={weight} 
        onChange={(e) => setWeight(e.target.value)} 
      />
      <Box display="flex" justifyContent="space-between" mt={2}>
        <Button 
          variant="contained" 
          color="secondary" 
          onClick={handleSeePastResult}
          className="past-result-button"
        >
          See past result
        </Button>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={handleSubmit}
          className="go-button"
        >
          GO!
        </Button>
      </Box>
      <Typography variant="body1" align="center" mt={2} className="bluetooth-status">
        Bluetooth status: Connected
      </Typography>
    </Container>
  );
};

export default DataInput;
