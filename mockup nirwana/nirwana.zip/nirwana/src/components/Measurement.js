import React, { useState, useEffect } from 'react';
import { useLocation, useHistory } from 'react-router-dom';
import { Container, Typography, Box, Button, CircularProgress } from '@mui/material';

const Measurement = () => {
  const location = useLocation();
  const history = useHistory();
  const { name, height, weight } = location.state || {};
  const [loading, setLoading] = useState(false);
  const [data, setData] = useState({
    bloodGlucose: '',
    spO2: '',
    heartRate: '',
    diabeticResult: ''
  });

  const getRandomValue = (min, max) => {
    return (Math.random() * (max - min) + min).toFixed(2);
  };

  const calculateBMI = (height, weight) => {
    const heightInMeters = height / 100;
    return (weight / (heightInMeters * heightInMeters)).toFixed(2);
  };

  const startMeasuring = () => {
    setLoading(true);
    setTimeout(() => {
      const newData = {
        bloodGlucose: `${getRandomValue(70, 140)} mg/dL`,
        spO2: `${getRandomValue(95, 100)}%`,
        heartRate: `${getRandomValue(60, 100)} bpm`,
        diabeticResult: 'You are safe!'
      };
      setData(newData);
      localStorage.setItem(`result-${new Date().toISOString()}`, JSON.stringify({ ...newData, time: new Date().toLocaleString() }));
      setLoading(false);
    }, 3500);
  };

  const handleNewPatient = () => {
    history.push('/data-input');
  };

  const handleEndSession = () => {
    history.push('/saved-results');
  };

  return (
    <Container maxWidth="xs" className="measurement-container">
      <Typography variant="h5" align="center">{name}</Typography>
      <Typography variant="body1" align="center">BMI: {calculateBMI(height, weight)}</Typography>
      <Box mt={2}>
        {loading ? (
          <Box className="loading-spinner">
            <CircularProgress />
          </Box>
        ) : (
          <Box className="measurement-result">
            <Typography variant="body1">Blood Glucose: {data.bloodGlucose}</Typography>
            <Typography variant="body1">SpO2: {data.spO2}</Typography>
            <Typography variant="body1">Heart Rate: {data.heartRate}</Typography>
            <Typography variant="body1">Your Early diabetic result: {data.diabeticResult}</Typography>
          </Box>
        )}
      </Box>
      <Button 
        variant="contained" 
        color="primary" 
        onClick={startMeasuring} 
        disabled={loading}
        className="start-measuring-button"
      >
        Start Measuring!
      </Button>
      <Box display="flex" justifyContent="space-between" mt={2}>
        <Button 
          variant="contained" 
          color="secondary" 
          onClick={handleNewPatient}
          className="new-patient-button"
        >
          Add New Patient
        </Button>
        <Button 
          variant="contained" 
          color="error" 
          onClick={handleEndSession}
          className="end-session-button"
        >
          End Session
        </Button>
      </Box>
      <Typography variant="body1" align="center" mt={2} className="bluetooth-status">
        Bluetooth status: Connected
      </Typography>
    </Container>
  );
};

export default Measurement;
