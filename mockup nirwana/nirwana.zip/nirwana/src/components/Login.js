import React, { useState } from 'react';
import { useHistory } from 'react-router-dom';
import { Button, TextField, Container, Typography } from '@mui/material';
import logo from '../itb.png';

const Login = () => {
  const history = useHistory();
  const [user, setUser] = useState('');
  const [password, setPassword] = useState('');

  const handleLogin = () => {
    if (user === 'joko' && password === 'widodo') {
      history.push('/data-input');
    } else {
      alert('Invalid credentials');
    }
  };

  return (
    <Container maxWidth="sm" className="login-container">
      <img src={logo} alt="Logo" className="login-logo" />
      <Typography variant="h4" align="center" className="login-title">Nirwana</Typography>
      <TextField label="User" fullWidth margin="normal" onChange={(e) => setUser(e.target.value)} className="login-input" />
      <TextField label="Password" type="password" fullWidth margin="normal" onChange={(e) => setPassword(e.target.value)} className="login-input" />
      <Button variant="contained" className="login-button" onClick={handleLogin}>Start</Button>
    </Container>
  );
};

export default Login;
