import React from 'react';
import { Container, Typography, Box, Button } from '@mui/material';
import { useHistory } from 'react-router-dom';

const SavedResults = () => {
  const history = useHistory();

  const results = Object.keys(localStorage)
    .filter((key) => key.startsWith('result-'))
    .map((key) => JSON.parse(localStorage.getItem(key)));

  const handleBack = () => {
    history.push('/measurement');
  };

  return (
    <Container maxWidth="xs" className="saved-results-container">
      <Button 
        variant="contained" 
        onClick={handleBack} 
        sx={{ position: 'absolute', top: '10px', left: '10px' }}
        className="back-button"
      >
        Back
      </Button>
      <Typography variant="h4" align="center" className="saved-results-title">Saved Results</Typography>
      {results.length > 0 ? (
        results.map((result, index) => (
          <Box key={index} className="saved-result">
            <Typography variant="body1" className="saved-result-time">{result.time}</Typography>
            <Typography variant="body1">Blood Glucose: {result.bloodGlucose}</Typography>
            <Typography variant="body1">SpO2: {result.spO2}</Typography>
            <Typography variant="body1">Heart Rate: {result.heartRate}</Typography>
            <Typography variant="body1">Diabetic Result: {result.diabeticResult}</Typography>
          </Box>
        ))
      ) : (
        <Typography variant="body1" align="center" mt={2}>No saved results</Typography>
      )}
    </Container>
  );
};

export default SavedResults;
